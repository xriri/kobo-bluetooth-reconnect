#!/bin/sh
# kobo-bluetooth-reconnect uninstaller

# Remove udev rule
rm -f /etc/udev/rules.d/97-bt-reconnect.rules

# Remove main script
rm -f /usr/local/Kobo/bt-reconnect.sh

# Remove this uninstall script
rm -f /usr/local/Kobo/bt-reconnect-uninstall.sh

# Clean up temp files
rm -f /tmp/bt-reconnect.log
rm -f /tmp/bt-connecting.lock
rm -f /tmp/bt-dbus.log
